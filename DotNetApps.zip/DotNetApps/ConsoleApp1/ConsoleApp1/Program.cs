﻿// See https://aka.ms/new-console-template for more information
WorkingWithDataTypes();
ConversionOfTypes();
void WorkingWithDataTypes();
    void ConversionOfTypes()
{
    int num1 = 100;
    double num2 = 100;
    bool isEverythingOk = true;
    string str = "Hello";
    string strNum = "100";

    var result1 = (double)num1;
    var result2 = (int)num2;

    var convert1 = Convert.ToString(num1);
    var convert2 = Convert.ToInt32(strNum);



}

for(int i =0; i< Array.length)
