﻿// See https://aka.ms/new-console-template for more information

using System.Diagnostics;

WorkingWithList();

void WorkingWithList(){
    List<string> shoppingList = new List<string>();
    Console.WriteLine($"Total items in shopping bag : {shoppingList.Count()}");
    shoppingList.Add("Bags");
    Log(new object[] { "item  added:", shoppingList[0] });
    shoppingList.Add("Dresses");
    Log(new object[] { "item  added:", shoppingList[1] });
    shoppingList.Add("Shoes");
    Log(new object[] { "item  added:", shoppingList[2] });
    //print
    PrintValues(shoppingList);
    Console.WriteLine($"Total items in shopping bag : {shoppingList.Count()}");
    shoppingList.Remove("Shoes");
    Log(new object[] { "item  removed: shoes" });
    PrintValues(shoppingList);
    Console.WriteLine($"Total items in shopping bag : {shoppingList.Count()}");

    Print(new object[]
    {
        "Comma-separated values of the shopping list",shoppingList[0],shoppingList[1],
                                     " The total count of items is:", shoppingList.Count() });


   

}
//11-02-2023:12

void Log(object[] pValues)
{
    string result = "";
    foreach (var item in pValues)
    {
        result = $"{result}, {item}";
    }

    var finalresult = $"[{DateTime.Now.ToString()}]:{result}";
    //Console Logging
    Console.ForegroundColor = ConsoleColor.Green;
    Console.WriteLine("--------");
    Console.WriteLine(finalresult);

    //Output Window
    Debug.WriteLine("----LOG----");
    Debug.WriteLine("finalResult");

}
    void Print<T>(T[] pValues)
    {
        string result = "";
        foreach (var item in pValues)
        {
            result = $"{result}, {item}";
        }
        result = result.TrimStart(',');
        Console.WriteLine(result);
    }

 void PrintValues<T>(List<T> pCollection)
    {
        //cde snippet for:foreach
        foreach (var item in pCollection)
        {
            Console.WriteLine(item);
        }
    }

//Test caling one constructor from another

