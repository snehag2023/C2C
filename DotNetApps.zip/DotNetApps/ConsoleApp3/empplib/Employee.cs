﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace empplib
{

    public class Employee : Person, IEmployeeContract
    {
        public event EventHandler Join;
        public event EventHandler resign;
        //ctor{
        //call base class constructor
        public Employee(): base()
        {
            this.ViewContract();
            this.Sign();
            this.EmpId = new Random(1000).Next();

            EmpUtils.EmpCount++;
        }

        //call current clas's constructor
        public Employee(string pAadhar):this()
        {
            this.Aadhar = pAadhar;
        }
        //
        public Employee(string pAadhar,string pMobile): base(pAadhar,pMobile)
        {
            this.ViewContract();
            this.Sign();
            this.EmpId = new Random(1000).Next();

            EmpUtils.EmpCount++;
        }
        public void triggerJoinEvent()
        {
            this.Join.Invoke(this,null);
        }

        public void triggerResignEvent()
        {
            this.resign.Invoke(this, null);
        }

        private int _EmpId;
        public int EmpId { get { return _EmpId; } private set { _EmpId = value; } }



        //variable inside a class are known as FIELDS
        private bool _contractSigned = false;
        private bool _hasReadContract = false;

        public void Sign()
        {
            _contractSigned = true;
        }
        public void ViewContract()
        {
            _hasReadContract = true;
        }



        public string Designation { get; set; }
        public double Salary { get; set; }
        public DateTime DOJ { get; set; }
        public bool IsActive { get; set; }
        public string Training(string pTraining)
        {

            return $"{this.Name} attended a training {pTraining}";
        }

        public string FillTimeSheet(List<string> ptask)
        {
            var csvTask = "";
            foreach (var task in ptask)
            {
                csvTask = $"{csvTask},{task}";

            }
            return $"{this.Name} has worked on {csvTask} on {DateTime.Now.ToShortDateString()}";
        }
        public override string Work()
        {
            return $"{this.Name} with {this.EmpId} works for 8hrs a day at KPMG";
        }
        public string Work(string task)
        {
          
            return $"{this.Name} with {this.EmpId} has {task} assigned on {DateTime.Today}";
        }
        public void SetTaxInfo(string TaxInfo)
        {
           this.TaxDetails = TaxInfo ;
        }
        public string GetTaxInfo()
        {
            return $"{this.Name}: Your tax details are:{this.TaxDetails}";
        }

    }

}
       
    

