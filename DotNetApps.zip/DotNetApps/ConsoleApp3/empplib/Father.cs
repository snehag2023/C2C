﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace empplib
{
    public class Father : Talents
    {
        //permitting differnt logic in derived

       
        public virtual string Settle()
        {
            return "Get a government job, retire by 60yrs and settle in native";
        }
        public string GetMarried()
        {
            return "Match horoscope, mary person from same religion,caste,settle in joint family";
        }
        public override string Drawing()
        {
            return "Drawing portraits,Tanjore paintings";
        }

        public override string WhatISDating()
        {
            return "meet special friend at restuarnat";
        }
    }

    //abstract == incomplete

    public abstract class Talents
    {
        public string GetDetails()
        {
            return "name and address";
        }
        public abstract string WhatISDating();
        public abstract string Drawing();
    }
    public class Child : Father
    { 
            public override string Drawing()
        {
            return "Drawing abstract art, Mandal art";

        }
        public override string WhatISDating()
        {
            return "Use Tinder App";
        }
        public override string Settle ()
        { 
        string howToLive = "Get a fat salaried job in fortune 500 company, visit differnent countries, Visit different countries,live outside hometown";
            howToLive = $"{howToLive} and later follow this : {base.Settle()}";
            return howToLive;
        }
        //function hiding
        new public string GetMarried()
        {
            return "Register marriage, suprise parents and settle abroad";
        }
    }


}
