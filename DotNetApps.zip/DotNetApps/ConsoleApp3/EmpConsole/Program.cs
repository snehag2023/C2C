﻿// See https://aka.ms/new-console-template for more information
using empplib;
using empplib;
using System.Security;

Person Sneha = new Person();
Sneha.Name = "Sneha";
Console.WriteLine(Sneha.Eat());

Person Lekha = new Person();
Lekha.Name = "Lekha";
Console.WriteLine(Lekha.Work());

//Base = new Derived()  //Remove 
Person Rushab = new Employee() {  Designation = "Intern", DOJ = DateTime.Now.AddMonths(-1) };
Rushab.Name = "Rushab";
((Employee)Rushab).Designation = "Analyst";
Console.WriteLine(Rushab.Work());
Console.WriteLine($"EmpId for {Rushab.Name} is {((Employee)Rushab).EmpId}");

Console.WriteLine(((Employee)Rushab).Training("C2C"));

//polymorphism
Father SharmajiFather = new Father();
Console.WriteLine($"Sharmaji's Father : {SharmajiFather.Settle()}");
Console.WriteLine($"Sharmaji's father gets married : {SharmajiFather.GetMarried()}");
Console.WriteLine($"Sharmaji's concept of drawaing (using abstract):{SharmajiFather.Drawing()}");
Console.WriteLine($"Sharmaji's concept of drawing (Using Abstract):{SharmajiFather.WhatISDating()}");

Father Sharmaji = new Child();
Console.WriteLine($"Sharmaji: {Sharmaji.Settle()}");
Console.WriteLine($"Sharmaji gets married: {Sharmaji.GetMarried()}");


Father SharmajiV2 = new Child();
Console.WriteLine($"Shatmaji V2 gats married : {((Child)SharmajiV2).GetMarried()}");

//See overloading compile-time polymorphism below 
Employee Cana = new Employee();
Cana.Name = "Cana";
Cana.Designation = "Security Systems Analyst";
Console.WriteLine(Cana.Work());
Console.WriteLine(Cana.Work("Solving bugs"));

//Exposing non public information through public method
Employee Sana = new Employee();
Sana.SetTaxInfo("I'm eligible in the 20% tax payer category");
Console.WriteLine(Sana.GetTaxInfo());

//Test calling one constructor from another
Person Sinchan = new Person("AA6546483893026", "+91 8965427865");
//This constructor should call the constructor that sets aadhar number
Console.WriteLine($"Aadha : {Sinchan.Aadhar} | Mobile number : {Sinchan.MobileNumber}");

Console.WriteLine($"Total Employee Count:{EmpUtils.EmpCount}");

//Adding employees to a temporary db = using satic list<employee>
EmpUtils.EmpDb.Add(Sana);
EmpUtils.EmpDb.Add(Cana);
EmpUtils.EmpDb.Add(new Employee("Bahhrrr84957356", "+91 9765487218") { Name="Nidha",Designation="Analyst", Salary=56666});
EmpUtils.EmpDb.Add(new Employee("Cahhrrr84957356", "+91 7338664484") { Name="Snake",Designation="Consultant", Salary=87666});
EmpUtils.EmpDb.Add(new Employee("AAhhrrr84957356", "+91 8382344884") { Name = "pug", Designation = "Senior analyst", Salary = 967659 });

//Get all employees whose aadhar card starts with AA
var resultList = EmpUtils.EmpDb.Where((emp) =>emp.Aadhar.StartsWith ("AA"));
resultList.ToList().ForEach((emp) => Console.WriteLine($"{emp.Aadhar} | {emp.Aadhar}"));
