﻿// See https://aka.ms/new-console-template for more information
using System;

partial class program
{
    //Declaration = new datatype
    delegate void Compute(int n1, int n2);
    delegate void Contractor(double budget);

    static void Main()
    {
        NewMethod();

    }

    private static void NewMethod()
    {
        //instantiate
        Action<double> RKmarriage = new Action<double>(
            (budget) =>
            {
                Console.WriteLine($"Registration charges :{budget * 95 / 100}");
                Console.WriteLine($"Reception charges: {budget * 5 / 100}");

            });
        Func<int, int, string> modifiedCompute = (n1, n2) => $"Addition:{n1 + n2}";
        modifiedCompute += (n1, n2) => $"Subtraction: {(n1 - n2)}";

        Predicate<int> isActive = (v) =>
        {
            if (v == 0) return false;
            else return true;
        };

        //Invoke all above delegates
        RKmarriage(500000);
        Console.WriteLine(modifiedCompute(100, 200));
        Console.WriteLine($"Output of Predicate: {isActive(1)}");
    }

    private static void RKmarriage()
    {
        Contractor RockyKushiMarriage = new Contractor((b) => Console.WriteLine($"Pandit Charges: {b * 20 / 100}"));
        RockyKushiMarriage += (b) => Console.WriteLine($"Catering Charges: {b * 50 / 100}");
        RockyKushiMarriage += (b) => Console.WriteLine($"Mandap Decorations: {b * 5 / 100}");
        RockyKushiMarriage += (b) => Console.WriteLine($"Couple arirve in porsche: {b * 15 / 100}");

        //Get Rocky  and Kushi married viz. Invoke the delagate like a function
        RockyKushiMarriage(500000);
    }

    private static void UsingLamdas()
    {
        Compute objShortCompute = new Compute((a, b) => Console.WriteLine($"Addition: {a + b}"));
        objShortCompute += (s, t) => Console.WriteLine($"Adittion: {s + t}");
        objShortCompute += (a, b) => Console.WriteLine($"Multiplication: {a * b}");
        objShortCompute += (s, t) => Console.WriteLine($"Division: {s / t}");



        //Invocation= like calling a function
        objShortCompute(250, -50);
    }

    private static void Delgateshort()
    {
        Compute objCompute = new Compute(AddFn);
        objCompute += SubFn;
        objCompute += MulFn;
        objCompute += DivFn;

        //Invoke the delegate exactly like a function
        objCompute(100, 200);
    }


    static void DivFn(int n1, int n2)
    {
        Console.WriteLine($"Output of division: {n1/n2}");
    }

  
static void MulFn(int n1, int n2)
    {;
        Console.WriteLine($"Output of multiplication: {n1 * n2}");
    }

   static  void AddFn(int n1, int n2)
    {
        Console.WriteLine($"Output of adittion: {n1 + n2}");
    }



static void SubFn(int n1, int n2)
    {
        Console.WriteLine($"Output of subraction: {n1 - n2}");
    }
}

