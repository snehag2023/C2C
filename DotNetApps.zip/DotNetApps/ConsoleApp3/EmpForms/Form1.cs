using empplib;

namespace EmpForms
{
    public partial class Form1 : Form
    {
        Employee KPMGEmp = new Employee();
        public Form1()

        {
            InitializeComponent();
            button1.Click += Button1_Click2;
            button1.Click += Button1_Click3;
            Employee Sneha = new Employee();
            KPMGEmp.Join += Sneha_Join;
            KPMGEmp.Join += Ramu_Join;
            KPMGEmp.Join += John_Join;
            KPMGEmp.resign += Sneha_Resign;


        }

        private void Sneha_Resign(object? sender, EventArgs e)
        {
            MessageBox.Show("Sneha Resigned kpmg successfully");
        }

        private void John_Join(object? sender, EventArgs e)
        {
            MessageBox.Show("John joined kpmg successfully");
        }



        private void Ramu_Join(object? sender, EventArgs e)
        {
            MessageBox.Show("Ramu joined kpmg successfully");
        }

        private void Sneha_Join(object? sender, EventArgs e)
        {

            MessageBox.Show("Sneha joined KPMH successfully");
        }

        private void Button1_Click3(object? sender, EventArgs e)
        {
            Sneha_Join(new Employee("AB6762338", "+91 8954289564"), null);

        }

        private void Button1_Click2(object? sender, EventArgs e)
        {
            MessageBox.Show("You clicked the button2");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You clicked the button");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Sneha_Join(null, null);
            //  John_Join(null, null);
            // Ramu_Join(null, null);
            KPMGEmp.triggerJoinEvent();


        }

        private void button3_Click(object sender, EventArgs e)
        {
            KPMGEmp.triggerResignEvent();
        }
    }
}