﻿

namespace ShapeLib
{
    public interface IShape
    {
        void Draw();
        void GetDetails();
    }

}